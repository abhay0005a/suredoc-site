# SureDocs Services - Website

## Overview

This is a static website for SureDocs Services, a document service provider based in Delhi NCR. The website provides information about their professional document services including driving licenses, birth certificates, passports, and ITR filing. It's built as a simple, responsive static website using HTML, CSS, and vanilla JavaScript.

## User Preferences

Preferred communication style: Simple, everyday language.
Privacy: Address information removed from all pages per user request (July 2025).
Interactivity: Enhanced website interactivity with filtering, animations, and comprehensive accounting services (July 2025).
WhatsApp Integration: All quote buttons and contact forms now redirect directly to WhatsApp for immediate customer service (July 2025).

## System Architecture

### Frontend Architecture
- **Static Website**: Built with vanilla HTML5, CSS3, and JavaScript
- **Multi-page Structure**: Traditional multi-page website with separate HTML files for each section
- **Responsive Design**: Mobile-first approach using CSS media queries
- **No Build Process**: Direct HTML/CSS/JS files without any bundling or compilation

### Technology Stack
- **HTML5**: Semantic markup with proper meta tags for SEO
- **CSS3**: Custom styles with CSS Grid and Flexbox for layout
- **Vanilla JavaScript**: Basic interactivity for navigation and smooth scrolling
- **Google Fonts**: External font loading (Inter and Poppins)
- **Font Awesome**: Icon library for social media and UI icons

## Key Components

### Pages Structure
1. **index.html** - Homepage with company introduction and overview
2. **services.html** - Detailed list of document services offered
3. **about.html** - Company background and team information
4. **contact.html** - Contact information and communication channels

### CSS Architecture
- **styles.css** - Single stylesheet containing all styles
- **Reset Styles**: Basic CSS reset for cross-browser compatibility
- **Typography System**: Hierarchical heading styles using Poppins font
- **Component-based Styling**: Modular CSS for navigation, cards, and layouts

### JavaScript Functionality
- **Mobile Navigation**: Hamburger menu toggle for responsive navigation
- **Smooth Scrolling**: Enhanced user experience for anchor links
- **Dynamic Navbar**: Background changes on scroll for better visibility
- **Event Handling**: Click outside to close mobile menu
- **Interactive Service Filtering**: Dynamic filtering of accounting services by category
- **Click Effects**: Ripple animations and hover effects on service cards
- **Scroll Progress**: Visual progress indicator at top of page
- **Real-time Form Validation**: Enhanced contact form with live validation
- **Animated Statistics**: Number counting animations when in viewport
- **Service Notifications**: Dynamic notifications for user interactions

## Data Flow

### Static Content Flow
1. **Direct File Serving**: HTML files served directly from the file system
2. **Asset Loading**: CSS and JavaScript files loaded via standard HTML linking
3. **External Resources**: Google Fonts and Font Awesome loaded from CDNs
4. **WhatsApp Integration**: Direct linking to WhatsApp Web for customer communication

### User Interaction Flow
1. **Navigation**: Client-side routing through traditional page navigation
2. **Mobile Menu**: JavaScript-powered responsive navigation
3. **Contact Methods**: External links to WhatsApp and email clients
4. **Smooth Scrolling**: Enhanced navigation within pages

## External Dependencies

### Content Delivery Networks (CDNs)
- **Google Fonts API**: Typography loading for Inter and Poppins fonts
- **Font Awesome CDN**: Icon library for UI elements and social media icons

### Third-party Integrations
- **WhatsApp Business**: Direct link to WhatsApp chat (wa.me/919205253438)
- **Email Integration**: Mailto links for direct email communication
- **Phone Integration**: Tel links for direct calling on mobile devices

### No Backend Dependencies
- No server-side processing required
- No database connections
- No API integrations
- No authentication systems

## Deployment Strategy

### Static Hosting Approach
- **File-based Deployment**: Direct deployment of HTML/CSS/JS files
- **CDN Compatible**: Can be served from any static hosting provider
- **No Server Requirements**: No backend infrastructure needed
- **Fast Loading**: Minimal overhead with direct file serving

### Hosting Options
- **GitHub Pages**: Direct deployment from repository
- **Netlify**: Static site hosting with form handling capabilities
- **Vercel**: Static hosting with edge network distribution
- **Traditional Web Hosting**: Any basic web hosting service

### Performance Considerations
- **Minimal Dependencies**: Only essential external resources loaded
- **Optimized Images**: Proper image formats and sizing needed
- **Caching Strategy**: Browser caching through proper HTTP headers
- **Mobile Optimization**: Responsive design for all device sizes

### SEO Implementation
- **Meta Tags**: Proper title and description tags for each page
- **Semantic HTML**: Structured markup for better search engine understanding
- **Local Business Focus**: Delhi NCR geographic targeting
- **Contact Information**: Clear business contact details for local SEO