// Mobile Navigation Toggle
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    if (hamburger && navMenu) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });

        // Close menu when clicking on nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function() {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });

        // Close menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!hamburger.contains(e.target) && !navMenu.contains(e.target)) {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            }
        });
    }
});

// Smooth Scrolling for Anchor Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Navbar Background on Scroll
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
            navbar.style.backdropFilter = 'blur(20px)';
            navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            navbar.style.backdropFilter = 'blur(10px)';
            navbar.style.boxShadow = 'none';
        }
    }
});

// FAQ Accordion
document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        
        if (question && answer) {
            question.addEventListener('click', function() {
                // Close all other FAQ items
                faqItems.forEach(otherItem => {
                    if (otherItem !== item) {
                        otherItem.classList.remove('active');
                    }
                });
                
                // Toggle current item
                item.classList.toggle('active');
            });
        }
    });
});

// Contact Form Handling
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(contactForm);
            const fullName = formData.get('fullName');
            const phone = formData.get('phone');
            const email = formData.get('email');
            const message = formData.get('message');
            
            // Basic validation
            if (!fullName || !phone || !message) {
                showNotification('Please fill in all required fields.', 'error');
                return;
            }
            
            // Phone number validation
            const phoneRegex = /^[0-9]{10}$/;
            if (!phoneRegex.test(phone)) {
                showNotification('Please enter a valid 10-digit phone number.', 'error');
                return;
            }
            
            // Email validation (if provided)
            if (email) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) {
                    showNotification('Please enter a valid email address.', 'error');
                    return;
                }
            }
            
            // Simulate form submission
            showNotification('Thank you! Your message has been sent. We will contact you soon.', 'success');
            contactForm.reset();
            
            // In a real implementation, you would send this data to your server
            console.log('Form submitted:', { fullName, phone, email, message });
        });
    }
});

// Notification System
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        font-family: 'Inter', sans-serif;
        font-weight: 500;
        max-width: 300px;
        transform: translateX(400px);
        transition: transform 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

// Scroll Animation
function handleScrollAnimation() {
    const animatedElements = document.querySelectorAll('.fade-in, .slide-in-left, .slide-in-right');
    
    animatedElements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < window.innerHeight - elementVisible) {
            element.classList.add('active');
        }
    });
}

window.addEventListener('scroll', handleScrollAnimation);
document.addEventListener('DOMContentLoaded', handleScrollAnimation);

// Statistics Counter Animation
function animateCounters() {
    const counters = document.querySelectorAll('.stat-number');
    
    counters.forEach(counter => {
        const target = parseInt(counter.textContent.replace(/\D/g, ''));
        const suffix = counter.textContent.replace(/[0-9]/g, '');
        let count = 0;
        const increment = target / 100;
        
        const updateCounter = () => {
            if (count < target) {
                count += increment;
                counter.textContent = Math.ceil(count) + suffix;
                setTimeout(updateCounter, 30);
            } else {
                counter.textContent = target + suffix;
            }
        };
        
        // Trigger animation when element is visible
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    observer.unobserve(entry.target);
                }
            });
        });
        
        observer.observe(counter);
    });
}

document.addEventListener('DOMContentLoaded', animateCounters);

// Service Cards Hover Effect
document.addEventListener('DOMContentLoaded', function() {
    const serviceCards = document.querySelectorAll('.service-card, .feature-card');
    
    serviceCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
});

// Lazy Loading for Images
document.addEventListener('DOMContentLoaded', function() {
    const images = document.querySelectorAll('img[data-src]');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
});

// Back to Top Button
document.addEventListener('DOMContentLoaded', function() {
    // Create back to top button
    const backToTopButton = document.createElement('button');
    backToTopButton.innerHTML = '<i class="fas fa-chevron-up"></i>';
    backToTopButton.className = 'back-to-top';
    backToTopButton.setAttribute('aria-label', 'Back to top');
    
    backToTopButton.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 50px;
        height: 50px;
        border: none;
        border-radius: 50%;
        background: linear-gradient(135deg, #3498db, #2980b9);
        color: white;
        font-size: 1.2rem;
        cursor: pointer;
        box-shadow: 0 4px 20px rgba(52, 152, 219, 0.3);
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 1000;
    `;
    
    document.body.appendChild(backToTopButton);
    
    // Show/hide button based on scroll position
    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            backToTopButton.style.opacity = '1';
            backToTopButton.style.visibility = 'visible';
        } else {
            backToTopButton.style.opacity = '0';
            backToTopButton.style.visibility = 'hidden';
        }
    });
    
    // Scroll to top when clicked
    backToTopButton.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    // Hover effect
    backToTopButton.addEventListener('mouseenter', function() {
        this.style.transform = 'scale(1.1)';
        this.style.boxShadow = '0 6px 25px rgba(52, 152, 219, 0.4)';
    });
    
    backToTopButton.addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
        this.style.boxShadow = '0 4px 20px rgba(52, 152, 219, 0.3)';
    });
});

// WhatsApp Click Tracking
document.addEventListener('DOMContentLoaded', function() {
    const whatsappLinks = document.querySelectorAll('a[href*="wa.me"]');
    
    whatsappLinks.forEach(link => {
        link.addEventListener('click', function() {
            console.log('WhatsApp link clicked');
            // You can add analytics tracking here
        });
    });
});

// Phone Click Tracking
document.addEventListener('DOMContentLoaded', function() {
    const phoneLinks = document.querySelectorAll('a[href^="tel:"]');
    
    phoneLinks.forEach(link => {
        link.addEventListener('click', function() {
            console.log('Phone link clicked');
            // You can add analytics tracking here
        });
    });
});

// Email Click Tracking
document.addEventListener('DOMContentLoaded', function() {
    const emailLinks = document.querySelectorAll('a[href^="mailto:"]');
    
    emailLinks.forEach(link => {
        link.addEventListener('click', function() {
            console.log('Email link clicked');
            // You can add analytics tracking here
        });
    });
});

// Service Card Click Tracking
document.addEventListener('DOMContentLoaded', function() {
    const serviceButtons = document.querySelectorAll('.service-btn, .service-card .btn');
    
    serviceButtons.forEach(button => {
        button.addEventListener('click', function() {
            const serviceName = this.closest('.service-card').querySelector('h3').textContent;
            console.log('Service inquiry:', serviceName);
            // You can add analytics tracking here
        });
    });
});

// Page Load Performance
window.addEventListener('load', function() {
    // Add loaded class to body for any CSS animations that should trigger after page load
    document.body.classList.add('loaded');
    
    // Log page load time
    const loadTime = performance.now();
    console.log('Page loaded in', Math.round(loadTime), 'milliseconds');
});

// Error Handling for Images
document.addEventListener('DOMContentLoaded', function() {
    const images = document.querySelectorAll('img');
    
    images.forEach(img => {
        img.addEventListener('error', function() {
            console.warn('Failed to load image:', this.src);
            // You could replace with a placeholder image here
        });
    });
});

// Interactive Service Filtering
document.addEventListener('DOMContentLoaded', function() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const serviceCards = document.querySelectorAll('.interactive-card');
    
    if (filterButtons.length > 0 && serviceCards.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                const filterValue = this.getAttribute('data-filter');
                
                // Filter service cards with smooth animation
                serviceCards.forEach(card => {
                    if (filterValue === 'all' || card.getAttribute('data-category') === filterValue) {
                        card.classList.remove('filtered-out');
                        card.style.display = 'block';
                        // Animate in
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'scale(1)';
                        }, 50);
                    } else {
                        card.classList.add('filtered-out');
                        // Animate out
                        setTimeout(() => {
                            if (card.classList.contains('filtered-out')) {
                                card.style.display = 'none';
                            }
                        }, 300);
                    }
                });
                
                // Show filter count
                const visibleCards = document.querySelectorAll('.interactive-card:not(.filtered-out)').length;
                showFilterNotification(`Showing ${visibleCards} services`, 'info');
            });
        });
    }
});

// Interactive Service Card Click Effects
document.addEventListener('DOMContentLoaded', function() {
    const interactiveCards = document.querySelectorAll('.interactive-card');
    
    interactiveCards.forEach(card => {
        // Add click ripple effect
        card.addEventListener('click', function(e) {
            // Create ripple element
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                border-radius: 50%;
                background: rgba(52, 152, 219, 0.3);
                transform: scale(0);
                animation: ripple 0.6s linear;
                width: ${size}px;
                height: ${size}px;
                left: ${x}px;
                top: ${y}px;
                pointer-events: none;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            // Remove ripple after animation
            setTimeout(() => {
                if (ripple.parentNode) {
                    ripple.parentNode.removeChild(ripple);
                }
            }, 600);
            
            // Show service details
            const serviceName = this.querySelector('h3').textContent;
            showServiceDetails(serviceName);
        });
    });
});

// Service Details Modal/Notification - Now redirects to WhatsApp
function showServiceDetails(serviceName) {
    // Direct redirect to WhatsApp for immediate consultation
    redirectToWhatsAppWithService(serviceName, 'inquiry');
}

// Enhanced Notification with Service Actions
function showFilterNotification(message, type = 'info', duration = 3000) {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.filter-notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `filter-notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'service' ? '#3498db' : '#27ae60'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        font-family: 'Inter', sans-serif;
        font-weight: 500;
        max-width: 300px;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        font-size: 0.9rem;
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after duration
    setTimeout(() => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, duration);
}

// Enhanced Service Button Interactions
document.addEventListener('DOMContentLoaded', function() {
    const serviceButtons = document.querySelectorAll('.service-btn');
    
    serviceButtons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px) scale(1.05)';
            this.style.boxShadow = '0 8px 25px rgba(52, 152, 219, 0.4)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = 'none';
        });
    });
});

// Interactive Statistics Animation
document.addEventListener('DOMContentLoaded', function() {
    const statNumbers = document.querySelectorAll('.stat-number');
    let hasAnimated = false;
    
    const animateStats = () => {
        if (hasAnimated) return;
        hasAnimated = true;
        
        statNumbers.forEach((stat, index) => {
            const finalValue = stat.textContent;
            const numericValue = parseInt(finalValue.replace(/\D/g, ''));
            const suffix = finalValue.replace(/[0-9]/g, '');
            
            let currentValue = 0;
            const increment = Math.ceil(numericValue / 50);
            const duration = 2000; // 2 seconds
            const stepTime = duration / (numericValue / increment);
            
            const counter = setInterval(() => {
                currentValue += increment;
                if (currentValue >= numericValue) {
                    currentValue = numericValue;
                    clearInterval(counter);
                }
                stat.textContent = currentValue + suffix;
            }, stepTime);
        });
    };
    
    // Trigger animation when stats section is visible
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !hasAnimated) {
                setTimeout(animateStats, 500);
            }
        });
    }, { threshold: 0.5 });
    
    const statsSection = document.querySelector('.stats');
    if (statsSection) {
        observer.observe(statsSection);
    }
});

// Add ripple animation keyframes to CSS
if (!document.querySelector('#ripple-styles')) {
    const style = document.createElement('style');
    style.id = 'ripple-styles';
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(2);
                opacity: 0;
            }
        }
        
        .interactive-card {
            position: relative;
            overflow: hidden;
        }
        
        .interactive-card:active {
            transform: translateY(-5px) scale(0.98);
        }
    `;
    document.head.appendChild(style);
}

// Scroll Progress Indicator
document.addEventListener('DOMContentLoaded', function() {
    // Create scroll progress bar
    const scrollProgress = document.createElement('div');
    scrollProgress.className = 'scroll-progress';
    document.body.appendChild(scrollProgress);
    
    // Update scroll progress
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset;
        const documentHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrollPercentage = (scrollTop / documentHeight) * 100;
        
        scrollProgress.style.width = scrollPercentage + '%';
    });
});

// Page Loading Animation
document.addEventListener('DOMContentLoaded', function() {
    // Create loading bar
    const loadingBar = document.createElement('div');
    loadingBar.className = 'page-loading active';
    document.body.appendChild(loadingBar);
    
    // Hide loading bar after page loads
    window.addEventListener('load', function() {
        setTimeout(() => {
            loadingBar.classList.remove('active');
            setTimeout(() => {
                if (loadingBar.parentNode) {
                    loadingBar.parentNode.removeChild(loadingBar);
                }
            }, 300);
        }, 500);
    });
});

// Interactive Homepage Service Cards
document.addEventListener('DOMContentLoaded', function() {
    const homeServiceCards = document.querySelectorAll('.interactive-hover');
    
    homeServiceCards.forEach(card => {
        card.addEventListener('click', function() {
            const serviceType = this.getAttribute('data-service');
            const serviceName = this.querySelector('h3').textContent;
            
            // Add click effect
            this.style.transform = 'translateY(-15px) scale(1.02)';
            
            setTimeout(() => {
                this.style.transform = '';
            }, 300);
            
            // Redirect to WhatsApp with service-specific message
            redirectToWhatsAppWithService(serviceName, serviceType);
        });
        
        // Add hover sound effect simulation
        card.addEventListener('mouseenter', function() {
            // Visual feedback for interaction
            this.style.transition = 'all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
        });
    });
});

// WhatsApp Redirect for Service Quotes
function redirectToWhatsAppWithService(serviceName, serviceType) {
    const whatsappMessage = `Hi SureDocs Services!

I'm interested in *${serviceName}* service.

Please provide:
- Detailed pricing information
- Required documents
- Processing time
- Next steps to proceed

Looking forward to your quick response!`;
    
    const whatsappUrl = `https://wa.me/919205253438?text=${encodeURIComponent(whatsappMessage)}`;
    
    // Show notification before redirect
    showNotification(`Connecting you to WhatsApp for ${serviceName} details...`, 'service', 3000);
    
    // Small delay for better user experience
    setTimeout(() => {
        window.open(whatsappUrl, '_blank');
    }, 1000);
}

// Enhanced Contact Form with WhatsApp Redirect
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        const inputs = contactForm.querySelectorAll('input, textarea');
        
        inputs.forEach(input => {
            // Real-time validation
            input.addEventListener('input', function() {
                validateField(this);
            });
            
            input.addEventListener('blur', function() {
                validateField(this);
            });
        });
        
        // Enhanced form submission with WhatsApp redirect
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            let isValid = true;
            inputs.forEach(input => {
                if (!validateField(input)) {
                    isValid = false;
                }
            });
            
            if (isValid) {
                // Get form data
                const formData = new FormData(this);
                const name = formData.get('name') || 'Customer';
                const email = formData.get('email') || '';
                const phone = formData.get('phone') || '';
                const service = formData.get('service') || 'General Inquiry';
                const message = formData.get('message') || '';
                
                // Create WhatsApp message
                const whatsappMessage = `Hi! I'm interested in your services.
                
*Name:* ${name}
*Email:* ${email}
*Phone:* ${phone}
*Service:* ${service}
*Message:* ${message}

Please provide more details and pricing. Thank you!`;
                
                // Show loading state
                const submitBtn = this.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Redirecting to WhatsApp...';
                submitBtn.disabled = true;
                
                // Redirect to WhatsApp after a short delay
                setTimeout(() => {
                    const whatsappUrl = `https://wa.me/919205253438?text=${encodeURIComponent(whatsappMessage)}`;
                    window.open(whatsappUrl, '_blank');
                    
                    showNotification('Redirecting to WhatsApp for direct communication!', 'success', 5000);
                    contactForm.reset();
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                }, 1500);
            } else {
                showNotification('Please fix the errors in the form before submitting.', 'error');
            }
        });
    }
});

function validateField(field) {
    const value = field.value.trim();
    const fieldName = field.name;
    let isValid = true;
    
    // Remove previous error styling
    field.style.borderColor = '#e0e0e0';
    
    // Validation logic
    if (field.required && !value) {
        field.style.borderColor = '#e74c3c';
        isValid = false;
    } else if (fieldName === 'phone' && value) {
        const phoneRegex = /^[6-9]\d{9}$/;
        if (!phoneRegex.test(value)) {
            field.style.borderColor = '#e74c3c';
            isValid = false;
        }
    } else if (fieldName === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            field.style.borderColor = '#e74c3c';
            isValid = false;
        }
    }
    
    // Show success styling for valid fields
    if (isValid && value) {
        field.style.borderColor = '#27ae60';
    }
    
    return isValid;
}

// Testimonial Click Interactions
document.addEventListener('DOMContentLoaded', function() {
    const testimonials = document.querySelectorAll('.testimonial-card');
    
    testimonials.forEach((testimonial, index) => {
        testimonial.addEventListener('click', function() {
            // Add ripple effect
            this.style.transform = 'translateY(-12px) scale(1.03)';
            this.style.boxShadow = '0 25px 50px rgba(0, 0, 0, 0.2)';
            
            setTimeout(() => {
                this.style.transform = '';
                this.style.boxShadow = '';
            }, 300);
            
            const authorName = this.querySelector('strong').textContent;
            showNotification(`"${authorName}" - One of our many satisfied customers! Join them today.`, 'info', 5000);
        });
    });
});

// Statistics Click Interactions
document.addEventListener('DOMContentLoaded', function() {
    const statItems = document.querySelectorAll('.stat-item');
    
    statItems.forEach((stat, index) => {
        stat.addEventListener('click', function() {
            const statLabel = this.querySelector('.stat-label').textContent;
            const statNumber = this.querySelector('.stat-number').textContent;
            
            const messages = [
                `🎯 ${statNumber} ${statLabel} and growing! Join our success story.`,
                `⭐ ${statNumber} ${statLabel} - Your trust drives our excellence.`,
                `🚀 ${statNumber} ${statLabel} - Experience matters in document services.`,
                `✅ ${statNumber} ${statLabel} - Quality service you can rely on.`
            ];
            
            showNotification(messages[index] || messages[0], 'info', 6000);
        });
    });
});

// Handle all "Get Quote" buttons with WhatsApp redirect
document.addEventListener('DOMContentLoaded', function() {
    const quoteButtons = document.querySelectorAll('.service-btn, .cta-btn');
    
    quoteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get service context from the button's parent card or section
            const serviceCard = this.closest('.service-card, .itr-service-card');
            let serviceName = 'General Service Inquiry';
            
            if (serviceCard) {
                const heading = serviceCard.querySelector('h3');
                if (heading) {
                    serviceName = heading.textContent.trim();
                }
            }
            
            // Redirect to WhatsApp with service information
            redirectToWhatsAppWithService(serviceName, 'quote');
        });
    });
});

// Handle accounting service cards click for quotes
document.addEventListener('DOMContentLoaded', function() {
    const accountingCards = document.querySelectorAll('.interactive-card');
    
    accountingCards.forEach(card => {
        card.addEventListener('click', function(e) {
            // Only handle if not clicking on filter functionality
            if (!e.target.closest('.filter-btn')) {
                const serviceName = this.querySelector('h3').textContent;
                const servicePrice = this.querySelector('.service-price')?.textContent || '';
                
                const whatsappMessage = `Hi SureDocs Services!

I'm interested in *${serviceName}* service.
${servicePrice ? `Pricing shown: ${servicePrice}` : ''}

Please provide:
- Complete pricing details
- Required documents list
- Processing timeline
- How to proceed with the application

Thank you!`;
                
                const whatsappUrl = `https://wa.me/919205253438?text=${encodeURIComponent(whatsappMessage)}`;
                
                showNotification(`Connecting you to WhatsApp for ${serviceName} consultation...`, 'service', 3000);
                
                setTimeout(() => {
                    window.open(whatsappUrl, '_blank');
                }, 1000);
            }
        });
    });
});
